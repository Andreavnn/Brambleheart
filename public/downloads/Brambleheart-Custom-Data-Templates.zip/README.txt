Brambleheart Custom Data Templates

Each JSON file has a required "type" field. Brambleheart uses that field to recognize the imported content as a Species, Spell, Talent, or Trait.

Import one or more JSON files from Settings > Data & Content > Custom Data.
Imported content is marked CUSTOM in Character Creation and is only shown there when Allow Custom Data is enabled on Step 1.

Trait template:
- traitKind: "culture" or "species"
- species: the Species the Trait belongs to
- skillGrants is optional and supports fixed Skills plus one or more choice lists.

Spell template:
- lore may use an existing Lore or a new custom Lore.
- signature true marks the spell as the Signature Spell for that Lore.

Talent categories:
- Combat
- Magic
- Movement
- Survival
- Social
- Utility
